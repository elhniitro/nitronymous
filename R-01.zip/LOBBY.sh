echo "PLEASE WAIT PROCESSING"
sleep 5
mv *FAKE_R-01/libtersafe.so /data/data/com.tencent.ig/lib
mv *FAKE_R-01/libtprt.so /data/data/com.tencent.ig/lib
mv *FAKE_R-01/libUE4.so /data/data/com.tencent.ig/lib
chmod -R 755 /data/data/com.tencent.ig/lib/libtersafe.so
chmod -R 755 /data/data/com.tencent.ig/lib/libtprt.so
chmod -R 755 /data/data/com.tencent.ig/lib/libUE4.so
echo "PROCESS COMPLETE, BACK TO PUBG AND APPLY MEMORY ANTIBAN"
echo "MADE BY TREND"